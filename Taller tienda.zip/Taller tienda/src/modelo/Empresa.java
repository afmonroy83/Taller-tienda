import java.util.Scanner;
 
 public class Empresa{
	private String nombre;
	private String apellido;
	private String direccion;
	private String codigo;
	private String telefono;
	private String rif;
	private int limitec;
	private String telefcontac;
	private String nombcontac;
	private boolean bcredito;
	private int montocred;
	
	public Empresa(){
		this.nombre = "";
		this.codigo = "";
		this.apellido = "";
		this.direccion= "";
		this.telefono = "";
		this.rif = "";
		this.limitec = 0;
		this.telefcontac = "";
		this.nombcontac = "";
		this.bcredito = false;
		this.montocred = 0;
	}
	

	public Empresa(String nombre, String apellido, String direccion, String codigo, String telefono, String rif, int limitec, String telefcontac, String nombcontac, boolean bcredito, int montocred){
		this.nombre = nombre;
		this.apellido = apellido;
		this.direccion = direccion;
		this.codigo = codigo;
		this.telefono = telefono;
		this.rif = rif;
		this.limitec = limitec;
		this.telefcontac = telefcontac;
		this.nombcontac = nombcontac;
		this.bcredito = bcredito;
		this.montocred = montocred;
	}
		
	public void capturar(){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Digite su nombre: ");
		nombre = scanner.nextLine();
		System.out.print("Digite su Apellido: ");
		apellido = scanner.nextLine();
		System.out.print("Digite su Direccion: ");
		direccion = scanner.nextLine();
		System.out.print("Digite su codigo: ");
		codigo = scanner.nextLine();
		System.out.print("Digite su telefono: ");
		telefono = scanner.nextLine();
		System.out.print("Digite su numero de rif: ");
		rif = scanner.nextLine();
		System.out.print("Digite su limite de credito: ");
		limitec = scanner.nextInt();
		System.out.println("Digite el nombre del contacto: ");
		nombcontac = scanner.nextLine();
		System.out.print("Digite el telefono del contacto: ");
		telefcontac = scanner.nextLine();
		System.out.print("Digite el beneficio crediticio: ");
		bcredito = scanner.nextBoolean();
		System.out.print("Digite el beneficio del monto crediticio que ha recibido acreditado: ");
		montocred = scanner.nextInt();
	}
	
	public void impresion(){
		System.out.println(this);
	}
	
	public static void eliminar(Empresa[] empresas, int cantidadEmpresas, String rif){
		for (int i = 0 ; i<cantidadEmpresas;i++){
			if(empresas[i].rif.equals(rif)){
				for(int j=i; j<cantidadEmpresas - 1;j++){
					empresas[j] = empresas[j + 1];
				}
				empresas[cantidadEmpresas - 1 ] = null;
				break;
			}
		}
	}
	public static void eliminarTodos(Empresa[] empresas){
		empresas = null;
	}
	
	public static void modificar(Empresa[] empresas, int cantidadEmpresas, String rif){
		for (int i = 0 ; i<cantidadEmpresas;i++){
			if(empresas[i].rif.equals(rif)){
				empresas[i].capturar();
			}
		}
	}
	
	public boolean equals(Empresa empresa){
		if (this.getRif().equals(empresa.getRif())){
			return true;
		}else{
			return false;
		}
	}
	
	public String toString(){
		String cadena= "";
		cadena+= "..::: Datos del Cliente :::..\n";
		cadena+= "Nombre:\t"+ nombre +" "+ apellido+"\n";
		cadena+= "Codigo:\t" + codigo +"\n";
		cadena+= "Direccion:\t"+ direccion +"\n";
		cadena+= "Telefono:\t" + telefono + "\n";
		cadena+= "rif:\t" + rif + "\n";
		cadena+= "limite crediticio:\t" + limitec + "\n";
		cadena+= "telefono del contacto:\t" + telefcontac + "\n";
		cadena+= "nombre del contacto:\t" + nombcontac + "\n";
		cadena+= "beneficio crediticio:\t" + bcredito + "\n";
		cadena+= "monto crediticio:\t" + montocred + "\n";
	
		cadena+= "..::: Fin de la empresa  :::..\n";
		return cadena;
	}		
	
	/**Getters y Setters**/
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getRif() {
		return rif;
	}
	public void setRif(String rif){
		this.rif = rif;
	}
	public int getLimitec(){
		return limitec;
	}
	public void setLimitec(int limitec){
		this.limitec = limitec;
	}
	public String getTelefcontac(){
		return telefcontac;
	}
	public void setTelefcontac(String telefcontac){
		this.telefcontac = telefcontac;
	}
	public String getNombcontac(){
		return nombcontac;
	}
	public void setNombcontac(String nombcontac){
		this.nombcontac = nombcontac;
	}
	public boolean getBcredito(){
		return bcredito;
	}
	public void setBcredito(final boolean bcredito){
		this.bcredito = bcredito;
	}
	public int getMontocred(){
		return montocred;
	}
	public void setMontocred(int montocred){
		this.montocred = montocred;
	}
}
