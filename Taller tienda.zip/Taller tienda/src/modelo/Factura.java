import java.util.Scanner;
 
 public class Factura{
	private String numero;
	private String fecha;
	private int impuesto;
	private int total;
	
	public Factura(){
		this.numero = "";
		this.fecha = "";
		this.impuesto = 0;
		this.total= 0;
	}
	
	public Factura(String numero, String fecha){
		this.numero = numero;
		this.fecha = fecha;
		this.impuesto = 0;
		this.total = 0;
	}
	
	public Factura(String fecha, String numero, int impuesto, int total){
		this.fecha = fecha;
		this.numero = numero;
		this.impuesto = impuesto;
		this.total = total;
	}
		
	public void capturar(){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Digite el numero de la Factura: ");
		numero = scanner.nextLine();
		System.out.print("Digite la fecha de la factura: ");
		fecha = scanner.nextLine();
		System.out.print("Digite el impuesto: ");
		impuesto = scanner.nextInt();
		System.out.print("Digite el total: ");
		total = scanner.nextInt();
	}
	
	public void impresion(){
		System.out.println(this);
	}
	
	public static void eliminar(Factura[] facturas, int cantidadFacturas, String numero){
		for (int i = 0 ; i<cantidadFacturas;i++){
			if(facturas[i].numero.equals(numero)){
				for(int j=i; j<cantidadFacturas - 1;j++){
					facturas[j] = facturas[j + 1];
				}
				facturas[cantidadFacturas - 1 ] = null;
				break;
			}
		}
	}
	public static void eliminarTodos(Factura[] facturas){
		facturas = null;
	}
	
	public static void modificar(Factura[] facturas, int cantidadFacturas, String numero){
		for (int i = 0 ; i<cantidadFacturas;i++){
			if(facturas[i].numero.equals(numero)){
				facturas[i].capturar();
			}
		}
	}
	
	public boolean equals(Factura factura){
		if (this.getNumero().equals(factura.getNumero())){
			return true;
		}else{
			return false;
		}
	}
	
	public String toString(){
		String cadena= "";
		cadena+= "..::: Datos de la factura :::..\n";
		cadena+= "numero:\t"+ numero +"\n";
		cadena+= "fecha:\t" + fecha +"\n";
		cadena+= "impuesto:\t"+ impuesto +"pesos \n";
		cadena+= "total:\t" + total + "pesos \n";
		cadena+= "..::: Fin de la factura :::..\n";
		return cadena;
	}		
	
	/**Getters y Setters**/
	
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public int getImpuesto() {
		return impuesto;
	}
	public void setImpuesto(int impuesto) {
		this.impuesto = impuesto;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	
}