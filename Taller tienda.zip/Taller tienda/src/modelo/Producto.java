import java.util.Scanner;
 
 public class Producto{
	private String nombre;
	private String codigo;
	private int precio;
	
	
	public Producto(){
		this.nombre = "";
		this.codigo = "";
		this.precio = 0;
		
	}
	

	public Producto(String nombre, String codigo, int precio){
		this.nombre = nombre;
		this.codigo = codigo;
		this.precio = precio;
	}
		
	public void capturar(){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Digite el nombre del producto: ");
		nombre = scanner.nextLine();
		System.out.print("Digite el codigo: ");
		codigo = scanner.nextLine();
		System.out.print("Digite el precio del producto: ");
		precio = scanner.nextInt();
		
	}
	
	public void impresion(){
		System.out.println(this);
	}
	
	public static void eliminar(Producto[] productos, int cantidadProductos, String codigo){
		for (int i = 0 ; i<cantidadProductos;i++){
			if(productos[i].codigo.equals(codigo)){
				for(int j=i; j<cantidadProductos - 1;j++){
					productos[j] = productos[j + 1];
				}
				productos[cantidadProductos - 1 ] = null;
				break;
			}
		}
	}
	public static void eliminarTodos(Producto[] productos){
		productos = null;
	}
	
	public static void modificar(Producto[] productos, int cantidadProductos, String codigo){
		for (int i = 0 ; i<cantidadProductos;i++){
			if(productos[i].codigo.equals(codigo)){
				productos[i].capturar();
			}
		}
	}
	
	public boolean equals(Producto producto){
		if (this.getCodigo().equals(producto.getCodigo())){
			return true;
		}else{
			return false;
		}
	}
	
	public String toString(){
		String cadena= "";
		cadena+= "..::: Datos del producto :::..\n";
		cadena+= "Nombre:\t"+ nombre +"\n";
		cadena+= "Codigo:\t" + codigo +"\n";
		cadena+= "precio:\t"+ precio +"\n";
		cadena+= "..::: Fin del Producto :::..\n";
		return cadena;
	}		
	
	/**Getters y Setters**/
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public int getPrecio() {
		return precio;
	}
	public void setPrecio(int precio) {
		this.precio = precio;
	}
}