public class PrincipalE{
	Empresa empresas[];
	public PrincipalE(){
		empresas= new Empresa[3];
		empresas[0] = new Empresa("Studio","S.A.","Zona Industrial","4","76321621","1", 1000 ,"78237217","Erika Paez",true, 11224);
		empresas[1] = new Empresa("Jum","No importa","Donde sea","5","3456773","2", 32, "456876313", "ANdres gonza", true, 345621);
		empresas[2] = new Empresa("Oreo","S.A.","Zona Industrial","6","76321621","3", 1000 ,"78237217","Felipe Monroy",true, 11224);
		
		
		Empresa.eliminar(empresas,3,"2");
		System.out.println("Ya borro Todo");
		
		Empresa.modificar(empresas, 3,"3");
		System.out.println("Cliente Empresa modificado");
		
		System.out.println(empresas[0]);
		System.out.println(empresas[1]);
		System.out.println(empresas[2]);
	}
	
	public static void main(String args[]){
		PrincipalE principalE = new PrincipalE();
	}
}