public class PrincipalP{
	Persona personas[];
	public PrincipalP(){
		personas = new Persona[3];
		personas[0] = new Persona("Diego","Rincon","sdfghj","7","12345678","938983743","84326437863");
		personas[1] = new Persona("Alberto","Suarez","hasjknaj","8","76238127","387126331","284378342");
		personas[2] = new Persona("Otro","apellido"," una direccion","9","jhsdja","8768647823","23467826438732");
		
		
		Persona.eliminar(personas,3,"2");
		System.out.println("Ya borro Todo");
		
		Persona.modificar(personas, 3 ,"9");
		System.out.println("Ya borro Todo");
		
		System.out.println(personas[0]);
		System.out.println(personas[1]);
		System.out.println(personas[2]);
	}
	
	public static void main(String args[]){
		PrincipalP principalP = new PrincipalP();
	}
}