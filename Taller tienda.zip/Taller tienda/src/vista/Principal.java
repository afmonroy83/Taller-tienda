public class Principal{
	Cliente clientes[];
	
	public Principal(){
		clientes= new Cliente[3];
		clientes[0] = new Cliente("Diego","Rincon","sdfghj","1","12345678");
		clientes[1] = new Cliente("Alberto","Suarez","hasjknaj","2","76238127");
		clientes[2] = new Cliente("Otro","apellido"," una direccion","3","jhsdja");
		
		
		Cliente.eliminar(clientes,3,"2");
		System.out.println("Ya borro Todo");
		
		System.out.println(clientes[0]);
		System.out.println(clientes[1]);
		System.out.println(clientes[2]);
	}
	
	public static void main(String args[]){
		Principal principal = new Principal();
	}
}