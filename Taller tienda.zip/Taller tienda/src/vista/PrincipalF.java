public class PrincipalF{
	Factura facturas[];
	public PrincipalF(){
		facturas = new Factura[3];
		facturas[0] = new Factura("12/07/2016","13",300,1000);
		facturas[1] = new Factura("28/03/2016","14",100,1000);
		facturas[2] = new Factura("21/10/2016","15",600,2000);
		
		
		Factura.eliminar(facturas,3,"2");
		System.out.println("Ya borro Todo");
		
		Factura.modificar(facturas,3,"14");
		System.out.println("Factura modificada");
		
		System.out.println(facturas[0]);
		System.out.println(facturas[1]);
		System.out.println(facturas[2]);
	}
	
	public static void main(String args[]){
		PrincipalF principalF = new PrincipalF();
	}
}