public class PrincipalPro{
	Producto productos[];
	public PrincipalPro(){
		productos = new Producto[3];
		productos[0] = new Producto("Comida","10",1000);
		productos[1] = new Producto("limpieza","11",1000);
		productos[2] = new Producto("aseo personal","12",2000);
		
		
		Producto.eliminar(productos,3,"2");
		System.out.println("Ya borro Todo");
		
		Producto.modificar(productos, 3 , "12" );
		System.out.println("Producto Modificado");
		
		System.out.println(productos[0]);
		System.out.println(productos[1]);
		System.out.println(productos[2]);
	}
	
	public static void main(String args[]){
		PrincipalPro principalPro = new PrincipalPro();
	}
}